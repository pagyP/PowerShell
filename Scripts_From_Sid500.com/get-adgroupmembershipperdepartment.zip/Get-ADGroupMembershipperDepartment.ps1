﻿function Get-ADGroupMembershipperDepartment {
  <#
    .SYNOPSIS
    The command retrieves group memberships from departments on a per user basis

    .DESCRIPTION
    Get-ADGroupMemberhipperDepartment lists the users group membership per department, even for nested groups.
    The Department field of the AD User must be filled with values. (for example HR, IT ...) 
    After the output, the system asks whether you want to print.

    .PARAMETER Department
    Provide the department name. (For example HR)

    .EXAMPLE
    Get-ADGroupMembershipperDepartment -Department HR
    Get-ADGroupMembershipperDepartment -Department 'PR & Marketing'

    .NOTES
    Author: Patrick Gruenauer
    Web: https://sid-500.com

    .LINK
    URLs to related sites
    The first link is opened by Get-Help -Online Get-ADGroupMembershipperDepartment

  #>


[CmdletBinding()]

param
(
    [Parameter(Position=0)]
    [String[]]$Department
)

$user=Get-ADUser -filter {department -eq $Department} -Properties name,department

$result=@()

foreach ($u in $user)
    
    {   
    
        $userdn = $u.DistinguishedName
        $Nested = "(member:1.2.840.113556.1.4.1941:=$userdn)"
        $a=Get-ADGroup -LDAPFilter $Nested -ResultPageSize 1000

        $x=($a.Name) -join "`r`n" 

        $result+=New-Object -TypeName PSObject -Property ([ordered]@{

                    'User'=$u.Name
                    'Department'=$u.department
                    'Groups'=$x

                    })
              
      
    }

$result | Format-Table -AutoSize -Wrap
$read=Read-Host -Prompt 'Do you want to print this? (Y/N)'
If ($read -eq 'Y')
{$result | Format-Table -AutoSize -Wrap | Out-Printer}

}




