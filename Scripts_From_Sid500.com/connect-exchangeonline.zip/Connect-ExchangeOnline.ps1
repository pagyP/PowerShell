﻿function Connect-ExchangeOnline  {

$UserCredential = Get-Credential
$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $UserCredential -Authentication Basic -AllowRedirection
Import-PSSession $Session -DisableNameChecking
$domain=Get-AcceptedDomain | Select-Object -ExpandProperty DomainName -First 1
""
""
Write-Output "***** Welcome to Exchange Online for the domain $domain *****"
""
Import-Module (Import-PSSession $session -AllowClobber) -Global -WarningAction SilentlyContinue

}
